from langchain.chat_models import ChatOpenAI
from sentence_transformers import CrossEncoder
from config import API_URL, API_KEY
import logging

# Setup logging for debugging
logger = logging.getLogger(__name__)

def create_qa_chain(vectorstore):
    """
    Initialize QA chain components:
    - LLM: Llama 3.3 70B via OpenAI-compatible API
    - Retriever: Top-50 semantic search candidates
    - Reranker: CrossEncoder for precision ranking
    
    Optimized for CPU inference on Windows 11
    """
    # Initializing Llama 3.3 70B via standard OpenAI-compatible interface
    # [cite: 13, 16] - Optimized for CPU inference
    llm = ChatOpenAI(
        openai_api_base=API_URL,
        openai_api_key=API_KEY,
        model_name="meta-llama/llama-3.3-70b-instruct",
        temperature=0,
        request_timeout=30  # Increase timeout for CPU inference
    )

    # Large initial retrieval for the reranker to work with
    # [cite: 23, 28] - More candidates = better reranking
    retriever = vectorstore.as_retriever(search_kwargs={"k": 50})
    
    # CPU-optimized reranker model (lightweight MiniLM)
    reranker = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v-2')

    return llm, retriever, reranker

def query_and_answer(llm, retriever, reranker, question):
    """
    Process query through two-stage retrieval:
    1. Semantic search: Get top-50 candidates via embeddings
    2. Reranking: Score with CrossEncoder for precision
    
    Returns formatted results with images and relevance scores
    Optimized for Windows 11 CPU execution
    """
    try:
        # Step 1: Semantic Search
        # [cite: 26, 27] - Fast embedding-based retrieval
        docs = retriever.get_relevant_documents(question)
        
        if not docs:
            logger.warning(f"No documents found for query: {question}")
            return "No relevant documents found for your query.", [], [], []

        # Step 2: CrossEncoder Reranking for high precision
        # [cite: 23, 28] - Accurate semantic relevance scoring
        pairs = [(question, doc.page_content) for doc in docs]
        scores = reranker.predict(pairs)
        sorted_docs_with_scores = sorted(zip(scores, docs), reverse=True)
        top_docs = sorted_docs_with_scores[:5]
        
        source_docs = [doc for _, doc in top_docs]
        # Explicitly convert scores to float for Windows compatibility
        rerank_scores = [float(score) for score, _ in top_docs]

        answer_parts = []
        images_to_display = []
        
        for idx, doc in enumerate(source_docs, 1):
            # Clean the display text by stripping internal OCR markers if present
            # [cite: 16, 22] - Separate OCR content from display
            display_text = doc.page_content.split("[IMAGE_CONTENT_START]")[0].strip()
            if not display_text:
                display_text = doc.page_content.split("[IMAGE TEXT]")[0].strip()
            if not display_text:
                display_text = doc.page_content
            
            # Create formatted header with source attribution
            header = f"### [{idx}] Source: {doc.metadata['file_name']} (Page {doc.metadata['page_no']}) | Score: {rerank_scores[idx-1]:.2f}"
            answer_parts.append(f"{header}\n{display_text}")
            
            # Collect images from pages with relevant content
            if doc.metadata.get('has_images', False) and doc.metadata.get('images'):
                images_to_display.extend(doc.metadata['images'])
        
        # Join with markdown separators for clarity
        final_context_block = "\n\n---\n\n".join(answer_parts)
        
        return final_context_block, source_docs, rerank_scores, images_to_display
        
    except Exception as e:
        logger.error(f"Error in query_and_answer: {str(e)}")
        return f"Error processing query: {str(e)}", [], [], []
