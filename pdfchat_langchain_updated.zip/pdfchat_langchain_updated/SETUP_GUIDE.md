# PDF Chat with Exact Text Extraction - Setup Guide

## ✅ Multi-File Upload & Query - CONFIRMED WORKING

Your system **already supports**:
- ✅ **Multiple PDF uploads in one go** (accept_multiple_files=True)
- ✅ **Querying across all uploaded PDFs**
- ✅ **Returning exact text from documents** (not LLM-generated answers)

---

## 📋 System Architecture

### 1. **app.py** - Streamlit UI
- File uploader supports multiple PDFs
- Caches results for repeat queries
- Displays exact text, relevance scores, and related images
- Downloads retrieved chunks as CSV

### 2. **ingestion.py** - Document Processing
- Converts PDFs to text and images
- Chunks text (1000 chars, 200 char overlap)
- Stores in ChromaDB (local vector database)
- Tracks processed files to avoid re-indexing

### 3. **querying.py** - Retrieval & Ranking
- Retrieves top 50 documents using embeddings
- Reranks with CrossEncoder (MS-MARCO model)
- Returns top 5 exact text excerpts with file & page info

### 4. **config.py** - Settings
- API endpoint for Llama 3.3 70B
- API key configuration

---

## 🚀 Quick Start

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Configure API (config.py)
```python
API_URL = "YOUR_LLAMA_3_3_70B_API_URL"
API_KEY = "YOUR_API_KEY"
```
*Note: LLM is only needed for embeddings fallback. The main system uses HuggingFace embeddings.*

### Step 3: Run the App
```bash
streamlit run app.py
```

### Step 4: Upload & Query
1. **Upload multiple PDFs** via sidebar (supports batch upload)
2. **Ask questions** in the text area
3. **Get exact text** from documents with:
   - File name & page number
   - Relevance scores
   - Related images (if present)
4. **Download results** as CSV

---

## 📊 Query Response Includes

1. **📄 Retrieved Text** - Exact excerpts from your PDFs
2. **📊 Relevance Scores** - CrossEncoder ranking scores (0-1)
3. **🖼️ Related Images** - Images from matching pages
4. **📚 Full Chunks** - Complete text with metadata
5. **⬇️ CSV Export** - Download for external use

---

## 💾 Data Storage

All data stored locally:
- `./chroma_db/` - Vector embeddings
- `./processed_files.json` - Tracked file names
- `./images/` - Extracted images
- **No cloud upload** - 100% secure

---

## 🔧 Customization

### Change Number of Results
In `querying.py`, line 32:
```python
top_docs = sorted_docs_with_scores[:5]  # Change 5 to desired number
```

### Change Chunk Size
In `ingestion.py`, line 58:
```python
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,      # Increase for longer excerpts
    chunk_overlap=200     # Increase for more overlap
)
```

### Use Different Embeddings Model
In `ingestion.py`, line 15:
```python
embed_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-mpnet-base-v2"  # Change model
)
```

---

## ⚡ Performance Tips

1. **Batch Upload** - Upload all PDFs at once (faster indexing)
2. **Caching** - Same queries use cached results instantly
3. **Top-K Retrieval** - Currently retrieves 50 docs, reranks to top 5
4. **Local Storage** - No API calls except for unused LLM config

---

## ❓ FAQ

**Q: Will it return exact text from documents?**
A: Yes! The system now retrieves exact text excerpts, not generated answers.

**Q: Can I upload multiple PDFs?**
A: Yes! Use the file uploader in the sidebar - it supports multiple files.

**Q: How are PDFs indexed?**
A: PDFs are converted to text chunks and stored in ChromaDB with vector embeddings.

**Q: What if I upload the same PDF twice?**
A: System tracks processed files in `processed_files.json` - duplicates are skipped.

**Q: Can I clear the index?**
A: Delete `./chroma_db/` folder and `./processed_files.json` file.

---

## 📦 Requirements Summary

- **langchain** - LLM framework
- **chromadb** - Vector database
- **streamlit** - Web UI
- **sentence-transformers** - Embeddings & reranking
- **PyMuPDF** - PDF processing
- **openai** - API client (configured but not used for text extraction)

---

**Status**: ✅ Ready to use with multiple PDFs and exact text retrieval!
