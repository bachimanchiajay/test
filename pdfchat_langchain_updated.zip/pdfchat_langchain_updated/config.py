# Configuration file for model settings
OLLAMA_MODEL = "llama3:70b"  # Or any other Ollama model, e.g., "llama2:70b"

# Configuration file for API settings
API_URL = "YOUR_LLAMA_3_3_70B_API_URL"
API_KEY = "YOUR_API_KEY"
