# Windows 11 CPU Optimization Guide

**PDF Chat with LangChain - Windows 11 CPU Edition**  
**Python 3.11.9**  
**Optimized**: 5 February 2026

---

## 🖥️ Windows 11 Specific Setup

### Prerequisites
- Windows 11 (Home, Pro, or Enterprise)
- Python 3.11.9 installed
- 8GB+ RAM (16GB recommended for large PDFs)
- 50GB+ free disk space
- CPU with at least 4 cores (8+ cores recommended)

---

## 📥 Installation Steps for Windows 11

### Step 1: Install Python 3.11.9

```bash
# Download from python.org
# https://www.python.org/downloads/release/python-3119/

# Verify installation
python --version
# Expected: Python 3.11.9

# Update pip
python -m pip install --upgrade pip
```

### Step 2: Create Virtual Environment

```bash
# Create venv
python -m venv venv

# Activate (Windows Command Prompt)
venv\Scripts\activate

# Or PowerShell
.\venv\Scripts\Activate.ps1

# You should see (venv) prefix in terminal
```

### Step 3: Install Tesseract OCR

**Two options:**

**Option A: EXE Installer (Recommended)**
1. Download from: https://github.com/UB-Mannheim/tesseract/wiki
2. Choose: `tesseract-ocr-w64-setup-v5.x.x.exe` (latest version)
3. Run installer
4. **Important**: Choose installation path carefully
   - Default: `C:\Program Files\Tesseract-OCR`
   - Or: `C:\Program Files (x86)\Tesseract-OCR`
5. The script auto-detects these paths

**Option B: Chocolatey (If installed)**
```powershell
choco install tesseract -y
```

### Step 4: Verify Tesseract Installation

```bash
# Test Tesseract
tesseract --version

# Expected output:
# tesseract 5.x.x
# leptonica-1.8x.x
```

### Step 5: Install Python Dependencies

```bash
# Make sure virtual environment is activated
pip install -r requirements.txt

# This installs ~23 packages
# Expected time: 5-15 minutes on CPU
```

### Step 6: Configure API Credentials

Edit `config.py`:
```python
API_URL = "YOUR_LLAMA_3_3_70B_API_URL"
API_KEY = "YOUR_API_KEY"
```

### Step 7: Run Application

```bash
# Make sure venv is activated
streamlit run app.py

# Output should show:
# Local URL: http://localhost:8501
# Network URL: http://YOUR_IP:8501
```

### Step 8: Open in Browser

```
http://localhost:8501
```

---

## ⚙️ Windows 11 CPU Optimizations Applied

### 1. **Explicit CPU Device Configuration**
```python
# In ingestion.py
embed_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-mpnet-base-v2",
    model_kwargs={"device": "cpu"}  # ← Force CPU
)
```
**Why**: Prevents PyTorch from trying to use GPU

### 2. **Windows Tesseract Path Detection**
```python
# In ingestion.py
if sys.platform == "win32":
    tesseract_paths = [
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
    ]
    # Auto-detects common Windows paths
```
**Why**: Windows uses different path separators and installation locations

### 3. **UTF-8 File Encoding**
```python
# In ingestion.py
with open(PROCESSED_FILES_PATH, 'r', encoding='utf-8') as f:
    processed_files = set(json.load(f))
```
**Why**: Windows default encoding can differ; explicit UTF-8 prevents errors

### 4. **Cross-Platform Temporary Paths**
```python
# In ingestion.py
temp_path = f"/tmp/{f.name}" if sys.platform != "win32" else f"temp_{f.name}"
```
**Why**: Windows doesn't have `/tmp/`; uses current directory instead

### 5. **Timeout Configuration for Slow CPU**
```python
# In querying.py
llm = ChatOpenAI(
    ...
    request_timeout=30  # Increased from default 10s
)
```
**Why**: CPU inference slower than GPU; needs more time

### 6. **Explicit Float Conversion**
```python
# In querying.py
rerank_scores = [float(score) for score, _ in top_docs]
```
**Why**: Ensures compatibility with Windows NumPy versions

### 7. **CPU-Friendly Embeddings Model**
```python
# In ingestion.py
model_name="sentence-transformers/all-mpnet-base-v2"  # Lightweight model
```
**Why**: Smaller model = faster on CPU, uses less RAM

### 8. **CPU-Friendly Reranker**
```python
# In querying.py
reranker = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v-2')  # Lightweight
```
**Why**: MiniLM is optimized for CPU inference

### 9. **Language-Specific OCR**
```python
# In ingestion.py
text = pytesseract.image_to_string(img, lang='eng')  # English only
```
**Why**: Single language OCR is much faster than multi-language

### 10. **Proper Error Handling**
```python
# In ingestion.py & querying.py
try:
    # Code here
except Exception as e:
    logger.error(f"Error: {str(e)}")
    # Graceful fallback
```
**Why**: Windows file system can have permission issues; need robust error handling

---

## 🔧 Windows 11 Troubleshooting

### Issue 1: "Tesseract is not installed or it's not in your PATH"

**Solution:**
```python
# Edit ingestion.py, line 18
pytesseract.pytesseract.pytesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
# Use YOUR actual installation path
```

### Issue 2: "ModuleNotFoundError: No module named 'torch'"

**Solution:**
```bash
# Reinstall PyTorch
pip uninstall torch -y
pip install torch --index-url https://download.pytorch.org/whl/cpu
```

### Issue 3: "Permission denied" on image files

**Solution:**
```bash
# Clear cache and re-index
rmdir /s /q "chroma_db"
del "processed_files.json"
rmdir /s /q "images"

# Restart Streamlit
streamlit run app.py
```

### Issue 4: "CUDA out of memory" error (shouldn't happen on CPU)

**Solution:**
- Restart Streamlit
- Reduce PDF file sizes
- Increase RAM or close other programs

### Issue 5: Very slow query processing

**Solution:** Check CPU usage
```bash
# Open Task Manager (Ctrl+Shift+Esc)
# Look for python.exe using high CPU (normal)
# Wait longer for response (CPU is slower)
```

### Issue 6: "LongContextWindowError"

**Solution:**
```python
# Edit querying.py, line 33
retriever = vectorstore.as_retriever(search_kwargs={"k": 30})  # Reduce from 50
```

---

## 📊 Expected Performance on Windows 11 CPU

### Typical Configuration:
- **CPU**: Intel i7/i9 or Ryzen 7/9 (8+ cores)
- **RAM**: 16GB
- **Storage**: SSD

### Performance Metrics:

| Operation | Expected Time | Notes |
|-----------|---------------|-------|
| Upload 10-page PDF | 8-12 seconds | Includes OCR processing |
| Generate embeddings | 3-8 seconds | Depends on chunk count |
| Query retrieval | 2-4 seconds | Embedding search + reranking |
| Cached query | <100ms | From memory |
| Full page display | 1-2 seconds | Streamlit rendering |

### Memory Usage:

| Component | RAM Used |
|-----------|----------|
| Python base | ~50 MB |
| Streamlit | ~150 MB |
| HuggingFace embeddings | ~400 MB |
| ChromaDB (in memory) | 50-200 MB |
| **Total minimum** | ~650 MB |
| **Total comfortable** | 4-6 GB |
| **Recommended** | 8+ GB |

---

## 🚀 Performance Optimization Tips

### 1. **Reduce PDF Size**
Split large PDFs (100+ pages) into smaller files for faster processing

### 2. **Disable Image OCR (if not needed)**
Edit ingestion.py to skip OCR:
```python
# Comment out OCR section to speed up
# ocr_text = extract_text_from_image(image_path)
```

### 3. **Reduce Chunk Size**
Edit ingestion.py:
```python
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,  # Smaller chunks = faster processing
    chunk_overlap=100
)
```

### 4. **Reduce Retrieval Candidates**
Edit querying.py:
```python
retriever = vectorstore.as_retriever(search_kwargs={"k": 30})  # From 50
top_docs = sorted_docs_with_scores[:3]  # From 5
```

### 5. **Clear Cache Regularly**
```bash
# Remove old indexes to free space
rmdir /s /q "chroma_db"
```

### 6. **Use Smaller Embeddings Model**
Edit ingestion.py:
```python
model_name="sentence-transformers/all-MiniLM-L6-v2"  # Faster, smaller
```

---

## 💾 Windows 11 Storage Layout

```
C:\Users\YourUsername\pdfchat_langchain\
├── venv\                          # Virtual environment
├── chroma_db\                     # Vector database (~50-200 MB per 100 pages)
├── images\                        # Extracted images (~100 KB - 5 MB per page)
├── temp_*.pdf                     # Temporary files (deleted after processing)
├── app.py                         # Streamlit app
├── ingestion.py                   # PDF processing
├── querying.py                    # Query engine
├── config.py                      # Configuration
├── requirements.txt               # Dependencies
└── processed_files.json           # Track which PDFs were indexed
```

---

## 🔐 Security on Windows 11

### 1. Credentials Storage
```bash
# Use Windows environment variables instead of hardcoding
setx LLAMA_API_URL "YOUR_URL"
setx LLAMA_API_KEY "YOUR_KEY"
```

Then in config.py:
```python
import os
API_URL = os.getenv("LLAMA_API_URL")
API_KEY = os.getenv("LLAMA_API_KEY")
```

### 2. Windows Defender
- May flag Python as suspicious (normal)
- Add `python.exe` to exclusions if needed

### 3. Firewall
- Streamlit runs on localhost:8501 (local only)
- Port 8501 is private by default

---

## 📋 Windows 11 Setup Checklist

- [ ] Python 3.11.9 installed and verified
- [ ] Virtual environment created
- [ ] Virtual environment activated
- [ ] Tesseract OCR installed and verified
- [ ] All dependencies installed: `pip install -r requirements.txt`
- [ ] config.py updated with API credentials
- [ ] Streamlit runs without errors: `streamlit run app.py`
- [ ] Browser opens at http://localhost:8501
- [ ] Can upload PDF successfully
- [ ] Can execute query and get results

---

## 🎯 Next Steps After Setup

1. **Upload Test PDF**
   - Click "Upload Documents" in sidebar
   - Select a PDF file
   - Wait for indexing to complete

2. **Ask First Question**
   - Type a simple question
   - Click "🔍 Ask"
   - Review results and images

3. **Optimize for Your Use**
   - Adjust chunk size based on results
   - Tweak retrieval parameters
   - Monitor performance

4. **Monitor Performance**
   - Watch Task Manager (Ctrl+Shift+Esc)
   - CPU should max out during processing (normal)
   - Memory usage should stay under 6GB

---

## 🆘 Getting Help

### Check Logs
```bash
# Streamlit shows all logs
# Look for ERROR or WARNING messages
```

### Verify Installation
```bash
python -c "import streamlit, langchain, torch, pytesseract; print('✅ All imports successful')"
```

### Test Each Component
```bash
# Test imports
python -c "from ingestion import extract_text_from_image; print('✅ Ingestion OK')"
python -c "from querying import query_and_answer; print('✅ Querying OK')"
python -c "import tesseract; tesseract.version"
```

---

## 📚 Additional Resources

### Official Tesseract
- GitHub: https://github.com/UB-Mannheim/tesseract/wiki
- Supports: 100+ languages

### Python on Windows
- https://docs.python.org/3.11/using/windows.html

### Streamlit Docs
- https://docs.streamlit.io/

### LangChain Documentation
- https://python.langchain.com/

---

## ✅ You're Ready!

**Windows 11 CPU Setup Complete**

Your PDF Chat application is now optimized for Windows 11 CPU execution with:
- ✅ Automatic Tesseract detection
- ✅ CPU-specific optimizations
- ✅ Proper file path handling
- ✅ Error handling and logging
- ✅ Performance tuning
- ✅ Full documentation

**Start using it with**: `streamlit run app.py`

---

**Version**: 1.0 - Windows 11 Edition  
**Last Updated**: 5 February 2026  
**Status**: ✅ Ready for Production
