# Fix: winerror 1114 c10.dll PyTorch Crash on Windows 11

## Problem
```
winerror 1114: [DLL error - failed to load c10.dll]
FileNotFoundError: Could not find module 'c10.dll'
```

**Root Cause:** PyTorch installed with CUDA support, but your Windows 11 system is CPU-only. The `c10.dll` file is a CUDA runtime library that doesn't exist on CPU-only machines.

---

## ✅ Quick Fix (5 minutes)

### Step 1: Remove Current PyTorch
```bash
pip uninstall torch torchvision torchaudio -y
```

### Step 2: Install CPU-Only PyTorch
```bash
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
```

### Step 3: Verify Installation
```bash
python -c "import torch; print('CUDA available:', torch.cuda.is_available())"
```

**Expected output:** `CUDA available: False`

---

## 🔧 If Quick Fix Didn't Work

### Option 1: Clean Virtual Environment (10 minutes)
```bash
# Deactivate current environment
deactivate

# Delete virtual environment
rmdir /s /q venv

# Recreate environment
python -m venv venv
venv\Scripts\activate

# Install CPU PyTorch FIRST (before other packages)
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu

# Install remaining dependencies
pip install -r requirements-windows-cpu.txt
```

### Option 2: Uninstall Visual C++ Redistributables (15 minutes)
Sometimes conflicting VC++ redistributables cause DLL loading issues:

1. Open **Settings → Apps → Apps & features**
2. Search for "Microsoft Visual C++"
3. Note the versions installed
4. Search for "redistributable"
5. Uninstall all Microsoft Visual C++ Redistributable packages
6. Download latest from: https://support.microsoft.com/en-us/help/2977003/
7. Reinstall CPU-only PyTorch

### Option 3: Manual PyTorch Site-Packages Fix (Advanced)
```bash
# Find your Python site-packages directory
python -c "import site; print(site.getsitepackages())"

# Navigate to torch directory
cd [path-to-site-packages]\torch

# Delete any remaining CUDA-related files
del *.dll
```

---

## 📋 Diagnostic Script

Create `test_pytorch.py`:

```python
import sys
import torch
import platform

print("=" * 60)
print("PyTorch Diagnostic Report")
print("=" * 60)
print(f"Python Version: {sys.version}")
print(f"Platform: {platform.system()} {platform.release()}")
print(f"PyTorch Version: {torch.__version__}")
print(f"CUDA Available: {torch.cuda.is_available()}")
print(f"CUDA Device Count: {torch.cuda.device_count() if torch.cuda.is_available() else 'N/A'}")
print(f"CPU Count: {torch.get_num_threads()}")

# Test tensor creation on CPU
try:
    tensor = torch.randn(10, 10).cpu()
    print(f"✓ CPU tensor creation successful")
    print(f"  Tensor shape: {tensor.shape}")
except Exception as e:
    print(f"✗ CPU tensor creation failed: {e}")

print("=" * 60)
```

Run it:
```bash
python test_pytorch.py
```

---

## 🐍 Updated Code - PyTorch CPU Force Mode

Your `ingestion.py` has been updated with Windows PyTorch CPU handling:

```python
# Windows PyTorch CPU Fix - Prevent CUDA DLL errors
try:
    import torch
    # Force CPU mode and disable CUDA to prevent DLL errors on CPU-only systems
    if sys.platform == "win32":
        logger.info("Windows detected - forcing PyTorch CPU mode")
        torch.cuda.is_available = lambda: False
        torch.cuda.device_count = lambda: 0
    logger.info(f"PyTorch version: {torch.__version__}")
    logger.info(f"CUDA available: {torch.cuda.is_available()}")
except Exception as e:
    logger.warning(f"PyTorch initialization warning: {e}")
```

---

## 📦 Use CPU-Only Requirements File

**For Windows CPU-only systems, use:**
```bash
pip install -r requirements-windows-cpu.txt
```

**This file explicitly specifies:**
- `torch==2.0.1+cpu` (CPU-only build)
- `torchvision==0.15.2+cpu` (CPU-only build)
- `torchaudio==2.0.2+cpu` (CPU-only build)

---

## 🚀 Verify Everything Works

After fixing PyTorch, test the full pipeline:

```bash
# 1. Verify Streamlit runs
streamlit run app.py

# 2. In browser (http://localhost:8501):
#    - Upload a PDF
#    - Query a question
#    - Check for errors in terminal

# 3. Watch logs for CPU processing info:
#    "Windows detected - forcing PyTorch CPU mode"
```

---

## ⚠️ If You Still See DLL Errors

### Check for Mixed Installations
```bash
# List all torch-related packages
pip list | findstr torch

# Should show ONLY these (no extras):
# - torch
# - torchvision  
# - torchaudio
# - sentence-transformers (depends on torch)
```

### Clear Python Cache
```bash
# Delete pycache directories
for /d /r . %d in (__pycache__) do @if exist "%d" rd /s /q "%d"

# Clear pip cache
pip cache purge

# Reinstall
pip install -r requirements-windows-cpu.txt
```

### Nuclear Option (Complete Reset)
```bash
# Backup your Chroma database
copy chroma_db chroma_db_backup

# Delete everything
pip uninstall -y -r <(pip freeze)

# Fresh install
python -m venv venv_new
venv_new\Scripts\activate
pip install -r requirements-windows-cpu.txt

# Restore Chroma (optional)
copy chroma_db_backup chroma_db
```

---

## 🔍 Troubleshooting Matrix

| Symptom | Cause | Solution |
|---------|-------|----------|
| `winerror 1114 c10.dll` | CUDA PyTorch on CPU | Use CPU-only index URL |
| `ModuleNotFoundError: No module named 'torch'` | PyTorch not installed | Install from requirements-windows-cpu.txt |
| `ImportError: cannot import name '_is_cuda_available'` | Incomplete torch uninstall | Delete venv and reinstall |
| `FileNotFoundError: tesseract not found` | Tesseract not installed | Download from UB-Mannheim/tesseract |
| `DLL load failed: %1 is not a valid Win32 application` | 32-bit/64-bit mismatch | Ensure Python and packages match (64-bit) |
| `RuntimeError: CUDA is not available` | Code assumes CUDA | Already fixed in updated ingestion.py |

---

## 📝 Permanent Solution

To prevent this issue in the future:

1. **Always use CPU index for PyTorch on CPU-only Windows:**
   ```bash
   pip install torch --index-url https://download.pytorch.org/whl/cpu
   ```

2. **Never install from default PyPI without checking PyTorch type**

3. **Keep requirements-windows-cpu.txt as your standard for Windows deployment**

4. **Add this to your environment setup script:**
   ```batch
   REM setup_windows.bat
   python -m venv venv
   call venv\Scripts\activate.bat
   pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
   pip install -r requirements-windows-cpu.txt
   ```

---

## ✅ Success Indicators

After applying this fix, you should see:

1. **No DLL errors when importing torch**
   ```python
   import torch  # ✓ No errors
   ```

2. **Streamlit starts without PyTorch errors**
   ```
   streamlit run app.py
   # ✓ Local URL: http://localhost:8501
   ```

3. **Logs show CPU mode**
   ```
   INFO: Windows detected - forcing PyTorch CPU mode
   INFO: CUDA available: False
   ```

4. **PDF uploads and queries work**
   ```
   ✓ File processed
   ✓ Embeddings created
   ✓ Results displayed
   ```

---

## 📞 Still Stuck?

Check these files:
- [WINDOWS_11_SETUP.md](WINDOWS_11_SETUP.md) - Full Windows setup guide
- [requirements-windows-cpu.txt](requirements-windows-cpu.txt) - CPU-only packages
- [ingestion.py](ingestion.py) - Updated with PyTorch CPU fix

Or run diagnostic:
```bash
python test_pytorch.py
```

The most common fix is **Step 1-3 above**. The entire process takes ~5 minutes.
