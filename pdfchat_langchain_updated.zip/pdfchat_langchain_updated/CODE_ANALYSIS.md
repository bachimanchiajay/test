# PDF Chat with LangChain - Complete Code Analysis

**Project Version**: 1.0  
**Python Version**: 3.11.9  
**Last Updated**: 4 February 2026

---

## 📋 Table of Contents

1. [Project Overview](#project-overview)
2. [Architecture](#architecture)
3. [Module Breakdown](#module-breakdown)
4. [Data Flow](#data-flow)
5. [Key Features](#key-features)
6. [Installation & Setup](#installation--setup)
7. [Configuration](#configuration)
8. [Dependencies](#dependencies)
9. [How to Use](#how-to-use)
10. [Advanced Features](#advanced-features)

---

## 📌 Project Overview

**PDF Chat with LangChain** is a Retrieval Augmented Generation (RAG) system that enables users to upload multiple PDF documents and ask natural language questions. The system returns exact text excerpts from the PDFs along with relevant images and metadata, rather than generating AI-synthesized answers.

### Key Objectives:
- ✅ Upload multiple PDFs simultaneously
- ✅ Extract text and images from PDFs
- ✅ Create searchable vector embeddings
- ✅ Return exact document excerpts (not generated text)
- ✅ Display relevant images from matched pages
- ✅ Rank results by relevance
- ✅ Cache results for performance
- ✅ Export results as CSV

---

## 🏗️ Architecture

The system follows a **Retrieval Augmented Generation (RAG)** pipeline with these components:

```
USER INPUT (PDF Files)
    ↓
[INGESTION] Extract text & images, Apply OCR
    ↓
[VECTORIZATION] Convert text to embeddings using HuggingFace
    ↓
[STORAGE] Store in ChromaDB (local vector database)
    ↓
USER QUERY
    ↓
[RETRIEVAL] Find top-50 similar chunks
    ↓
[RERANKING] Score using CrossEncoder (top-5)
    ↓
[FORMATTING] Separate text from images
    ↓
USER OUTPUT (Text + Images + Metadata)
```

### Technology Stack:

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **Frontend** | Streamlit | Web UI for interaction |
| **Embeddings** | HuggingFace Sentence-Transformers | Text vectorization |
| **Vector DB** | ChromaDB | Store and retrieve embeddings |
| **Reranking** | CrossEncoder (MS-MARCO) | Relevance scoring |
| **PDF Processing** | PyMuPDF (fitz) | Extract text & images |
| **OCR** | Tesseract + pytesseract | Extract text from images |
| **Image Processing** | Pillow (PIL) | Handle image files |
| **LLM Framework** | LangChain | Orchestration layer |
| **Data Processing** | Pandas | Data transformation |

---

## 📦 Module Breakdown

### 1. **app.py** - Streamlit Web Interface

**Purpose**: User-facing web application for uploading PDFs and querying documents.

#### Key Components:

**a) Page Configuration**
```python
st.set_page_config(
    page_title="Knowledge Chat Bot for Technical Manuals",
    layout="wide",          # Two-column layout
    page_icon="📄",
    initial_sidebar_state="expanded"
)
```
- Sets page title, layout, and icon
- Expanded sidebar for file upload controls

**b) Custom CSS Styling**
- Green header (#4CAF50) for branding
- Rounded buttons and text areas for modern UI
- Consistent sidebar background color

**c) File Upload Section (Sidebar)**
```python
uploaded_files = st.file_uploader(
    "Upload PDF document(s)",
    type="pdf",
    accept_multiple_files=True
)
```
- Allows multiple PDF uploads in one action
- Only accepts .pdf files
- Shows success message with file count

**d) Caching System**
```python
@st.cache_resource(show_spinner=False)
def get_vectorstore(files):
    return ingest_and_index(files)
```
- `@st.cache_resource`: Caches vectorstore between reruns
- Prevents re-indexing of same files
- Significantly improves performance

**e) Query Processing**
```python
if st.button("🔍 Ask", type="primary") and user_question and vectorstore is not None:
    # Check cache for previous queries
    if user_question in st.session_state.query_cache:
        # Use cached result (instant)
    else:
        # Execute new query and cache result
```
- Checks session state cache for repeat queries
- Two-level caching: vectorstore + query results
- Prevents unnecessary reprocessing

**f) Result Display**
- **Retrieved Text**: Shows exact excerpts with file and page info
- **Relevance Scores**: Table with CrossEncoder scores (0-1 scale)
- **Images**: Displays images from relevant pages in 3-column grid
- **Raw Chunks**: DataFrame with full metadata
- **CSV Export**: Download button for results

**g) Session State Management**
```python
if 'query_cache' not in st.session_state:
    st.session_state.query_cache = {}
```
- Maintains query cache during Streamlit session
- Survives across page reruns
- Cleared when session ends or browser refreshed

#### UI Layout:
- **Left Column (2/3 width)**: Main content area
  - Title and branding
  - Question input (text area)
  - Results display sections
- **Right Column (1/3 width)**: Information panel
  - Instructions
  - Upload status
  - Security information

---

### 2. **ingestion.py** - Document Processing & Indexing

**Purpose**: Converts PDFs into searchable vector embeddings with OCR support.

#### Key Functions:

**a) extract_text_from_image(image_path)**
```python
def extract_text_from_image(image_path):
    img = Image.open(image_path)
    text = pytesseract.image_to_string(img)
    return text.strip()
```
- Uses Tesseract OCR to extract text from images
- Handles errors gracefully (returns empty string on failure)
- Enables image content to be searchable

**b) ingest_and_index(files)**

**Step 1: Initialize or Load Existing Database**
```python
embed_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2")
if os.path.exists(INDEX_PATH):
    vectorstore = Chroma(persist_directory=INDEX_PATH, ...)
    processed_files = set(json.load(f))
```
- Uses pre-trained HuggingFace embeddings model
- Loads existing ChromaDB if it exists
- Tracks processed files to avoid duplicates

**Step 2: Identify New Files**
```python
new_files = [f for f in files if f.name not in processed_files]
```
- Only processes files not previously indexed
- Saves time and storage on re-uploads

**Step 3: Extract Content from PDFs**
```python
doc = fitz.open(temp_path)
for page_no in range(len(doc)):
    page = doc[page_no]
    text = page.get_text() or ""
```
- Opens each PDF with PyMuPDF (fitz)
- Iterates through all pages
- Extracts raw text from each page
- Normalizes whitespace: `re.sub(r"\s+", " ", text)`

**Step 4: Extract Images with OCR**
```python
for img_index, img in enumerate(page.get_images(full=True)):
    # Extract image bytes and save to file
    image_paths.append(image_path)
    
    # Extract text from image
    ocr_text = extract_text_from_image(image_path)
    if ocr_text:
        image_texts.append(ocr_text)
```
- Finds all images on each page
- Saves images to `./images/` directory
- Runs OCR on each image
- Collects OCR results

**Step 5: Combine Text and Image Content**
```python
combined_text = text
if image_texts:
    combined_text = text + " [IMAGE TEXT] " + " ".join(image_texts)
```
- Merges page text with image OCR text
- `[IMAGE TEXT]` marker separates page and image content
- Enables searching image content while keeping it identifiable

**Step 6: Create Document Objects**
```python
doc_obj = Document(
    page_content=combined_text,
    metadata={
        "file_name": f.name,
        "page_no": page_no + 1,
        "images": image_paths,
        "has_images": len(image_paths) > 0,
        "image_texts": image_texts
    }
)
```
- Wraps content and metadata in LangChain Document format
- Metadata tracks source information and images
- `has_images` flag for quick detection

**Step 7: Split Documents into Chunks**
```python
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,      # Characters per chunk
    chunk_overlap=200     # Overlap between chunks
)
docs = text_splitter.split_documents(documents)
```
- Breaks long documents into manageable chunks
- Chunk size: 1000 characters (optimal for embeddings)
- Overlap: 200 characters (captures context at boundaries)
- Ensures complete sentences aren't split

**Step 8: Store in Vector Database**
```python
if vectorstore is None:
    vectorstore = Chroma.from_documents(docs, embed_model, ...)
else:
    vectorstore.add_documents(docs)
vectorstore.persist()
```
- Creates new ChromaDB if doesn't exist
- Adds to existing database if it does
- Persists to disk for future use
- Embeddings generated automatically by ChromaDB

**Step 9: Update Tracking**
```python
processed_files.update(f.name for f in new_files)
with open(PROCESSED_FILES_PATH, 'w') as f:
    json.dump(list(processed_files), f)
```
- Records which files have been processed
- Prevents duplicate processing on future uploads

#### Data Storage:
- `./chroma_db/` - Vector embeddings and metadata
- `./images/` - Extracted images from PDFs
- `./processed_files.json` - List of processed files

---

### 3. **querying.py** - Query Processing & Retrieval

**Purpose**: Handles user queries, retrieves relevant documents, and ranks results.

#### Key Functions:

**a) create_qa_chain(vectorstore)**
```python
def create_qa_chain(vectorstore):
    llm = ChatOpenAI(
        openai_api_base=API_URL,
        openai_api_key=API_KEY,
        model_name="meta-llama/llama-3.3-70b-instruct",
        temperature=0
    )
    
    retriever = vectorstore.as_retriever(search_kwargs={"k": 50})
    reranker = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v-2')
    
    return llm, retriever, reranker
```

**Components**:
1. **LLM (ChatOpenAI)**
   - Base URL: Custom Llama 3.3 API endpoint
   - Model: `meta-llama/llama-3.3-70b-instruct`
   - Temperature: 0 (deterministic, no randomness)
   - *Note: Currently not used for answer generation; used for future extensibility*

2. **Retriever**
   - Uses vectorstore's built-in retrieval
   - Returns top-50 most similar chunks (k=50)
   - Similarity search uses cosine distance on embeddings
   - Configured to retrieve many candidates for reranking

3. **CrossEncoder Reranker**
   - Model: `cross-encoder/ms-marco-MiniLM-L-6-v-2`
   - Purpose: Re-score chunks for relevance
   - Produces scores between 0-1
   - More accurate than embedding similarity

**b) query_and_answer(llm, retriever, reranker, question)**

**Step 1: Retrieve Candidates**
```python
docs = retriever.get_relevant_documents(question)
```
- Gets top-50 embedding-similar chunks
- Fast retrieval using vector similarity
- May include less relevant results

**Step 2: Rerank for Relevance**
```python
pairs = [(question, doc.page_content) for doc in docs]
scores = reranker.predict(pairs)
sorted_docs_with_scores = sorted(zip(scores, docs), reverse=True)
top_docs = sorted_docs_with_scores[:5]
```
- Creates (question, chunk) pairs
- CrossEncoder scores relevance of each pair
- Returns scores between 0 and 1
- Sorts by score (highest first)
- Selects top-5 most relevant

**Step 3: Extract and Format Results**
```python
for doc in source_docs:
    page_text = doc.page_content.split("[IMAGE TEXT]")[0].strip()
    
    if doc.metadata.get('has_images', False):
        answer_parts.append(f"[{file} | Page {page}]\n{page_text}\n📸 Image(s) present")
        images_to_display.extend(doc.metadata['images'])
    else:
        answer_parts.append(f"[{file} | Page {page}]\n{page_text}")
```
- Separates page text from OCR text for clean display
- Identifies chunks with images
- Collects image paths for display
- Formats output with metadata

**Step 4: Return Results**
```python
return answer, source_docs, rerank_scores, images_to_display
```
- Returns 4 values:
  - **answer**: Formatted text for display
  - **source_docs**: Original document objects
  - **rerank_scores**: Relevance scores (0-1)
  - **images_to_display**: Paths to relevant images

#### How Exact Text Retrieval Works:

Unlike generative QA systems that synthesize answers, this system:
1. Matches query against existing document text
2. Returns exact excerpts (no generation)
3. Preserves original formatting and content
4. Provides source attribution (file & page)
5. Shows relevance scoring for transparency

---

### 4. **config.py** - Configuration

**Purpose**: Centralized configuration for API endpoints and credentials.

```python
OLLAMA_MODEL = "llama3:70b"          # Legacy Ollama config (unused)
API_URL = "YOUR_LLAMA_3_3_70B_API_URL"    # Custom LLM endpoint
API_KEY = "YOUR_API_KEY"              # API authentication token
```

#### Configuration Points:
- **API_URL**: Points to custom Llama 3.3 70B inference endpoint
- **API_KEY**: Authentication token for API access
- Must be updated before running the application
- Values should be from your LLM provider

#### Security Note:
- Never commit actual credentials to version control
- Use environment variables in production
- Consider using `.env` files with python-dotenv

---

## 📊 Data Flow Diagram

### Upload Flow:
```
User Upload (Multiple PDFs)
    ↓
app.py: st.file_uploader()
    ↓
ingestion.py: ingest_and_index(files)
    ├─ For each PDF:
    │  ├─ Open with PyMuPDF
    │  ├─ Extract page text
    │  ├─ Extract images
    │  ├─ Run OCR on images
    │  └─ Combine text + OCR text
    │
    ├─ Split into 1000-char chunks (200 overlap)
    │
    ├─ Generate embeddings (HuggingFace)
    │
    └─ Store in ChromaDB
         ├─ ./chroma_db/ (vectors)
         ├─ ./images/ (image files)
         └─ ./processed_files.json (tracking)
```

### Query Flow:
```
User Question
    ↓
app.py: Display in UI
    ↓
Session Cache Check
    ├─ Hit: Return cached result (instant)
    └─ Miss: Execute query
    
    ↓
querying.py: query_and_answer()
    ├─ Retrieve: Top-50 similar chunks (embedding search)
    ├─ Rerank: Score top-50 with CrossEncoder
    ├─ Select: Top-5 results
    ├─ Format: Separate text from images
    └─ Return: Text + Images + Scores
    
    ↓
app.py: Display Results
    ├─ Show exact text excerpts
    ├─ Show relevance scores
    ├─ Show images (3-column grid)
    ├─ Show raw chunks (table)
    └─ Show download button
    
    ↓
Cache: Save result for future queries
```

---

## ✨ Key Features

### 1. **Multi-Document Support**
- Upload multiple PDFs simultaneously
- Automatic deduplication (no re-processing)
- Search across all documents at once
- Track file sources in results

### 2. **OCR & Image Indexing**
- Extract text from embedded images
- Make image text searchable
- Display images when they match queries
- Support for various image formats

### 3. **Intelligent Ranking**
- Two-stage retrieval (embedding + reranking)
- CrossEncoder for accurate relevance scoring
- Top-50 candidates → Top-5 results
- Relevance scores (0-1 scale) shown to users

### 4. **Exact Text Retrieval**
- Returns exact document excerpts (no generation)
- Preserves original formatting
- Clear source attribution
- No information loss or paraphrasing

### 5. **Performance Optimization**
- Vectorstore caching (persistent on disk)
- Query result caching (session-based)
- Prevents duplicate processing
- Fast repeat queries (instant)

### 6. **Rich Result Display**
- Formatted text with metadata
- Relevance scoring table
- Inline image display
- Raw chunk DataFrame
- CSV export functionality

### 7. **Local Data Storage**
- All data stored locally (./chroma_db/, ./images/)
- No cloud uploads or external storage
- Offline capability (after initial indexing)
- Privacy-preserving

---

## 🚀 Installation & Setup

### Prerequisites:
- Python 3.11.9
- macOS, Linux, or Windows
- Tesseract OCR engine
- 8GB+ RAM (for Llama model API)

### Step 1: Install Tesseract OCR

**macOS:**
```bash
brew install tesseract
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt-get install tesseract-ocr
```

**Windows:**
- Download from: https://github.com/UB-Mannheim/tesseract/wiki
- Run installer and note installation path
- Update ingestion.py if path differs from default

### Step 2: Clone Repository
```bash
cd /Users/ajaykumar/pdfchat_langchain
```

### Step 3: Create Virtual Environment
```bash
python3.11 -m venv venv
source venv/bin/activate  # macOS/Linux
# or
venv\Scripts\activate  # Windows
```

### Step 4: Install Python Dependencies
```bash
pip install -r requirements.txt
```

### Step 5: Configure API Credentials
Edit `config.py`:
```python
API_URL = "https://your-llama-endpoint.com/v1"
API_KEY = "your-api-key-here"
```

### Step 6: Run Application
```bash
streamlit run app.py
```

**Output:**
```
  You can now view your Streamlit app in your browser.

  Local URL: http://localhost:8501
  Network URL: http://your-ip:8501
```

Open http://localhost:8501 in your browser.

---

## ⚙️ Configuration

### Environment Variables (Optional)

Create `.env` file:
```bash
LLAMA_API_URL="https://your-endpoint.com/v1"
LLAMA_API_KEY="your-key"
```

Update `config.py` to use:
```python
import os
from dotenv import load_dotenv

load_dotenv()
API_URL = os.getenv("LLAMA_API_URL")
API_KEY = os.getenv("LLAMA_API_KEY")
```

### Tuning Parameters

**In ingestion.py - Chunk size:**
```python
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,    # Increase for longer excerpts
    chunk_overlap=200   # Increase for more overlap
)
```

**In querying.py - Retrieval count:**
```python
retriever = vectorstore.as_retriever(search_kwargs={"k": 50})  # Candidates
top_docs = sorted_docs_with_scores[:5]                        # Final results
```

**In app.py - Cache size:**
- Streamlit session state has no size limit
- Each cached query stored as tuple: (answer, docs, scores, images)
- Estimated ~10-50KB per query

---

## 📦 Dependencies

All dependencies are Python 3.11.9 compatible:

| Package | Version | Purpose | Python 3.11 Compatible |
|---------|---------|---------|------------------------|
| langchain | 0.0.354 | LLM framework | ✅ |
| langchain-community | 0.0.13 | Vector stores | ✅ |
| langchain-huggingface | 0.0.3 | Embeddings | ✅ |
| chromadb | 0.4.12 | Vector database | ✅ |
| streamlit | 1.28.1 | Web framework | ✅ |
| sentence-transformers | 2.6.0 | Embeddings & reranking | ✅ |
| PyMuPDF | 1.23.8 | PDF processing | ✅ |
| pytesseract | 0.3.10 | OCR interface | ✅ |
| Pillow | 10.1.0 | Image processing | ✅ |
| pandas | 1.5.3 | Data handling | ✅ |
| numpy | 1.24.3 | Numerical computing | ✅ |
| torch | 2.0.1 | ML framework (optional) | ✅ |
| openai | 1.6.1 | API client | ✅ |

---

## 💡 How to Use

### Basic Usage Flow:

#### 1. Launch Application
```bash
streamlit run app.py
```

#### 2. Upload PDFs
- Click "Upload Documents" in sidebar
- Select one or multiple PDF files
- Wait for indexing to complete (~1-2 min per 100 pages)
- See ✅ confirmation message

#### 3. Ask Question
- Type question in text area
- Example: "What is the insurance coverage?"
- Click "🔍 Ask" button
- Wait for retrieval (~2-5 seconds)

#### 4. Review Results
- **📄 Retrieved Text**: Exact excerpts with page numbers
- **📊 Relevance Scores**: CrossEncoder scores (0-1)
- **🖼️ Relevant Images**: Images from matched pages
- **📚 Retrieved Chunks**: Full data table
- **⬇️ Download CSV**: Export for external use

### Example Queries:

**Across all documents:**
- "Find information about coverage limits"
- "What are the claim procedures?"
- "Show me details about exclusions"
- "Search for premium calculation details"

**Getting images:**
- Queries matching pages with images will automatically show images
- OCR text from images is searchable
- Images display in 3-column grid below text

### Clearing Data:

To reset and re-index all documents:
```bash
# Delete vector database
rm -rf ./chroma_db/

# Delete tracked files
rm ./processed_files.json

# Delete images
rm -rf ./images/

# Re-upload documents in Streamlit UI
```

---

## 🔧 Advanced Features

### 1. Batch Processing

Process multiple PDFs programmatically:
```python
from ingestion import ingest_and_index
from pathlib import Path

pdf_files = Path("./pdfs").glob("*.pdf")
vectorstore = ingest_and_index(list(pdf_files))
```

### 2. Custom Embeddings Model

Change embeddings in ingestion.py:
```python
embed_model = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"  # Faster, smaller
    # or
    # model_name="sentence-transformers/all-mpnet-base-v2"  # Better quality (default)
)
```

### 3. Custom Reranker

Replace CrossEncoder in querying.py:
```python
from sentence_transformers import CrossEncoder
reranker = CrossEncoder('ms-marco-TinyBERT-L-2-v2')  # Faster
# or keep default for best quality
```

### 4. Adjust Chunk Size

For technical documents with short sections:
```python
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,      # Shorter chunks for precision
    chunk_overlap=100    # Less overlap to save space
)
```

For narratives with long passages:
```python
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=2000,     # Longer chunks for context
    chunk_overlap=400    # More overlap for connectivity
)
```

### 5. Modify Number of Results

Return more or fewer results:
```python
# In querying.py
top_docs = sorted_docs_with_scores[:10]  # Return top-10 instead of top-5

# In app.py - update display accordingly
```

### 6. Add Custom Preprocessing

Before chunking in ingestion.py:
```python
# Add custom preprocessing
combined_text = combined_text.lower()  # Lowercase
combined_text = re.sub(r"[^\w\s]", "", combined_text)  # Remove special chars
```

---

## 📊 Performance Metrics

### Typical Performance (on standard hardware):

| Operation | Time | Notes |
|-----------|------|-------|
| Upload single PDF (10 pages) | 5-10 sec | Includes OCR |
| Generate embeddings (100 chunks) | 2-5 sec | One-time |
| Retrieve query results | 1-3 sec | Embedding search + reranking |
| Cached query | <100 ms | Instant from memory |
| Display results | <1 sec | Streamlit rendering |

### Storage Requirements:

| Item | Size | Notes |
|------|------|-------|
| ChromaDB vectors (per 100 chunks) | ~50 MB | Depends on model |
| Extracted images (per page) | 100 KB - 5 MB | Varies by quality |
| Processed files tracking | <1 KB | JSON file |
| **Total per 100-page PDF** | ~100-200 MB | Rough estimate |

---

## ❓ Troubleshooting

### Issue: OCR not working
**Solution:**
- Verify Tesseract installed: `tesseract --version`
- Check pytesseract can find it: `python -c "import pytesseract; pytesseract.pytesseract_cmd"`

### Issue: Out of memory
**Solution:**
- Reduce chunk size in ingestion.py
- Process PDFs in smaller batches
- Use smaller embeddings model

### Issue: Slow retrieval
**Solution:**
- Reduce k=50 in querying.py
- Use faster embeddings model (all-MiniLM-L6-v2)
- Use faster reranker (TinyBERT)

### Issue: API connection errors
**Solution:**
- Verify API_URL is correct in config.py
- Check API_KEY is valid
- Test connection: `curl YOUR_API_URL`

### Issue: PDFs not indexing
**Solution:**
- Check PDF is valid: Open in PDF reader
- Ensure file has .pdf extension
- Check disk space available

---

## 🔐 Security Considerations

### Data Privacy:
✅ All data stored locally  
✅ No external API calls for indexing  
✅ Embeddings generated offline  
✅ PDF content never leaves your machine  

### Credentials:
⚠️ Store API_KEY in environment variable (not config.py)  
⚠️ Never commit credentials to version control  
⚠️ Use .gitignore to exclude sensitive files  

### File Permissions:
- `./chroma_db/` - Readable/writable by user
- `./images/` - Readable/writable by user
- `./processed_files.json` - Readable/writable by user

---

## 📝 File Structure

```
pdfchat_langchain/
├── app.py                    # Streamlit UI
├── ingestion.py              # PDF processing & indexing
├── querying.py               # Query & retrieval logic
├── config.py                 # Configuration
├── requirements.txt          # Python dependencies
│
├── chroma_db/               # Vector database (auto-created)
│   ├── data/
│   └── metadata/
│
├── images/                  # Extracted images (auto-created)
│   ├── document1_page1_img0.png
│   └── ...
│
├── processed_files.json     # Tracked files (auto-created)
│
└── Documentation files:
    ├── README.md            # Project overview
    ├── CODE_ANALYSIS.md     # This file
    ├── SETUP_GUIDE.md       # Setup instructions
    ├── OCR_SETUP.md         # OCR configuration
```

---

## 🎯 Summary

**PDF Chat with LangChain** provides a complete end-to-end solution for:

1. **Document Management**: Upload, process, and index PDFs
2. **Content Extraction**: Text and image extraction with OCR
3. **Semantic Search**: Find relevant content using embeddings
4. **Result Ranking**: Rank by relevance using CrossEncoder
5. **User Interface**: Beautiful Streamlit web application
6. **Performance**: Efficient caching and vectorization

The system excels at finding exact information in documents while maintaining source attribution and providing visual context through images. It's ideal for technical manuals, insurance documents, legal papers, and other document collections.

**Key Advantage**: Returns exact text from documents, not AI-generated answers, ensuring accuracy and traceability.

---

## 📞 Support & Maintenance

### Regular Maintenance:
- Clear cache if behavior changes: Delete `./chroma_db/`
- Update dependencies: `pip install --upgrade -r requirements.txt`
- Monitor disk space for growing image collection

### Extending Functionality:
- Add custom preprocessing in ingestion.py
- Modify reranking strategy in querying.py
- Enhance UI in app.py
- Add filtering/sorting in query results

### Version History:
- **v1.0** (Feb 4, 2026): Initial release with OCR support
  - Multi-document upload
  - Exact text retrieval
  - Image extraction and OCR
  - CrossEncoder reranking
  - Session caching

---

**Project Status**: ✅ Production Ready  
**Python Version**: 3.11.9  
**Last Updated**: 4 February 2026
