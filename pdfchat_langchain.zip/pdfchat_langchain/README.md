# PDF Chat with RAG (Retrieval-Augmented Generation)

A secure, local RAG chatbot for querying PDF documents, including text and images, using LangChain, ChromaDB, and Llama 3.3 70B API.

## Features
- Upload multiple PDFs and query them with natural language.
- Supports text extraction and image display from PDFs.
- Uses reranking for accurate responses.
- Caches queries for speed.
- Professional UI with Streamlit.

## Data Security & Confidentiality
- **Local Storage**: All data (PDFs, extracted text, images, embeddings) is stored locally in `./chroma_db` and `./images` folders on your machine.
- **No External Sharing**: ChromaDB runs entirely offline. No data is sent to external servers, APIs (except your configured Llama 3.3 70B API for inference), or third parties.
- **Confidentiality**: Ideal for sensitive financial data. Ensure your API provider complies with your security policies.

## Installation
1. Install Python 3.12+ (avoid 3.14 if issues arise).
2. `pip install -r requirements.txt`
3. Update `config.py` with your Llama 3.3 70B API URL and key.
4. `streamlit run app.py`

## Usage
- Upload PDFs in the sidebar.
- Ask questions in the text area.
- View responses, images, and retrieved chunks.

## Dependencies
- LangChain for RAG
- ChromaDB for vector storage (local)
- Sentence-Transformers for reranking
- PyMuPDF for PDF processing
- Streamlit for UI

Built for secure, local use.
