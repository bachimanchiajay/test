from langchain.chat_models import ChatOpenAI
from sentence_transformers import CrossEncoder
from config import API_URL, API_KEY

def create_qa_chain(vectorstore):
    # Use custom LLM with LangChain for Llama 3.3 70B
    llm = ChatOpenAI(
        openai_api_base=API_URL,
        openai_api_key=API_KEY,
        model_name="meta-llama/llama-3.3-70b-instruct",
        temperature=0
    )

    # Create retriever with higher k for reranking
    retriever = vectorstore.as_retriever(search_kwargs={"k": 50})

    # Initialize reranker
    reranker = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v-2')

    return llm, retriever, reranker

def query_and_answer(llm, retriever, reranker, question):
    # Retrieve documents
    docs = retriever.get_relevant_documents(question)

    # Rerank documents
    pairs = [(question, doc.page_content) for doc in docs]
    scores = reranker.predict(pairs)
    sorted_docs_with_scores = sorted(zip(scores, docs), reverse=True)
    top_docs = sorted_docs_with_scores[:5]
    source_docs = [doc for _, doc in top_docs]
    rerank_scores = [score for score, _ in top_docs]

    # Separate page text and image text for display
    answer_parts = []
    images_to_display = []
    
    for doc in source_docs:
        # Extract page text (remove OCR text for display)
        page_text = doc.page_content.split("[IMAGE TEXT]")[0].strip() if "[IMAGE TEXT]" in doc.page_content else doc.page_content
        
        # Check if images are present and relevant
        if doc.metadata.get('has_images', False):
            # Add page text with image indicator
            answer_parts.append(f"[{doc.metadata['file_name']} | Page {doc.metadata['page_no']}]\n{page_text}\n📸 *Image(s) present on this page below*")
            
            # Add images to display list
            if doc.metadata.get('images'):
                images_to_display.extend(doc.metadata['images'])
        else:
            # Just add page text if no images
            answer_parts.append(f"[{doc.metadata['file_name']} | Page {doc.metadata['page_no']}]\n{page_text}")
    
    answer = "\n\n".join(answer_parts)

    return answer, source_docs, rerank_scores, images_to_display
