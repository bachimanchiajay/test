from langchain_openai import ChatOpenAI
from sentence_transformers import CrossEncoder
from config import API_URL, API_KEY

def create_qa_chain(vectorstore):
    # Use custom LLM with LangChain for Llama 3.3 70B
    llm = ChatOpenAI(
        openai_api_base=API_URL,
        openai_api_key=API_KEY,
        model_name="meta-llama/llama-3.3-70b-instruct",
        temperature=0
    )

    # Create retriever with higher k for reranking
    retriever = vectorstore.as_retriever(search_kwargs={"k": 50})

    # Initialize reranker
    reranker = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v-2')

    return llm, retriever, reranker

def query_and_answer(llm, retriever, reranker, question):
    # Retrieve documents
    docs = retriever.get_relevant_documents(question)

    # Rerank documents
    pairs = [(question, doc.page_content) for doc in docs]
    scores = reranker.predict(pairs)
    sorted_docs_with_scores = sorted(zip(scores, docs), reverse=True)
    top_docs = sorted_docs_with_scores[:20]
    source_docs = [doc for _, doc in top_docs]
    rerank_scores = [score for score, _ in top_docs]

    # Create context
    context = "\n\n".join(
        f"[{doc.metadata['file_name']} | Page {doc.metadata['page_no']}]\n{doc.page_content}"
        for doc in source_docs
    )

    # Prepare prompt
    messages = [
        {"role": "system", "content": "You are an insurance document assistant."},
        {"role": "user", "content": f"{context}\n\n{question}"}
    ]

    # Get response
    response = llm.invoke(messages)
    answer = response.content.strip()

    return answer, source_docs, rerank_scores
