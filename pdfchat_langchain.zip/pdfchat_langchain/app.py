import streamlit as st
import pandas as pd
import os
from ingestion import ingest_and_index
from querying import create_qa_chain, query_and_answer

st.set_page_config(
    page_title="Knowledge Chat Bot for Technical Manuals",
    layout="wide",
    page_icon="📄",
    initial_sidebar_state="expanded"
)

# Custom CSS for professional UI
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #4CAF50;
        text-align: center;
        margin-bottom: 2rem;
    }
    .sidebar .sidebar-content {
        background-color: #f0f2f6;
    }
    .stButton>button {
        background-color: #4CAF50;
        color: white;
        border-radius: 5px;
        padding: 0.5rem 1rem;
    }
    .stTextArea textarea {
        border-radius: 5px;
    }
</style>
""", unsafe_allow_html=True)

st.markdown('<h1 class="main-header">📄 RAG Chat with Meta-Llama-3.3-70B</h1>', unsafe_allow_html=True)

# Sidebar for file upload
with st.sidebar:
    st.header("📤 Upload Documents")
    uploaded_files = st.file_uploader(
        "Upload PDF document(s)",
        type="pdf",
        accept_multiple_files=True
    )
    if uploaded_files:
        st.success(f"✅ {len(uploaded_files)} file(s) uploaded")

# Cache the vectorstore
@st.cache_resource(show_spinner=False)
def get_vectorstore(files):
    return ingest_and_index(files)

vectorstore = None
if uploaded_files:
    with st.spinner("🔄 Indexing documents... This may take a few minutes."):
        vectorstore = get_vectorstore(uploaded_files)
    st.sidebar.success("✅ Documents indexed successfully")

# Initialize cache in session state
if 'query_cache' not in st.session_state:
    st.session_state.query_cache = {}

# Main content
col1, col2 = st.columns([2, 1])

with col1:
    st.subheader("💬 Ask Your Question")
    user_question = st.text_area(
        "Enter your question:",
        placeholder="E.g. Search the UFLIE, USPONSOR, and FGMAIN manuals for EXCHANGE...",
        height=120
    )

    if st.button("🔍 Ask", type="primary") and user_question and vectorstore is not None:
        # Check cache
        if user_question in st.session_state.query_cache:
            st.info("📋 Using cached response for this query.")
            answer, source_docs, scores = st.session_state.query_cache[user_question]
        else:
            llm, retriever, reranker = create_qa_chain(vectorstore)
            
            with st.spinner("🤖 Generating answer..."):
                answer, source_docs, scores = query_and_answer(llm, retriever, reranker, user_question)
            
            # Cache the result
            st.session_state.query_cache[user_question] = (answer, source_docs, scores)
        
        st.subheader("🧠 LLM Response")
        st.write(answer)
        
        # Collect and display images from retrieved chunks
        all_images = []
        for doc in source_docs:
            if "images" in doc.metadata:
                all_images.extend(doc.metadata["images"])
        all_images = list(set(all_images))  # Remove duplicates
        
        if all_images:
            st.subheader("🖼️ Related Images")
            cols = st.columns(min(len(all_images), 3))  # Up to 3 images per row
            for i, img_path in enumerate(all_images):
                with cols[i % 3]:
                    st.image(img_path, caption=os.path.basename(img_path), use_column_width=True)
        
        # Prepare data for display
        df_out = pd.DataFrame({
            "file_name": [doc.metadata["file_name"] for doc in source_docs],
            "page_no": [doc.metadata["page_no"] for doc in source_docs],
            "chunk_text": [doc.page_content for doc in source_docs],
            "score": scores
        })
        
        st.subheader("📚 Retrieved Chunks")
        st.dataframe(df_out, use_container_width=True)
        
        # Download button
        csv_data = df_out.to_csv(index=False).encode()
        st.download_button(
            label="⬇️ Download Chunks as CSV",
            data=csv_data,
            file_name="retrieved_chunks.csv",
            mime="text/csv"
        )

with col2:
    st.subheader("ℹ️ Info")
    st.info("Upload PDF files from the sidebar to begin chatting with your documents. If your query relates to images in the PDFs, relevant images will be displayed along with the response.")
    if not uploaded_files:
        st.warning("👈 No files uploaded yet")

# Footer
st.markdown("---")
st.markdown("Built with ❤️ using LangChain, Streamlit, FAISS, and Llama 3.3 70B API")
