import os
import re
import json
import fitz  # PyMuPDF
import pytesseract
from PIL import Image
from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma

INDEX_PATH = "./chroma_db"
PROCESSED_FILES_PATH = "./processed_files.json"
IMAGES_DIR = "./images"

def extract_text_from_image(image_path):
    """Extract text from image using OCR"""
    try:
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img)
        return text.strip()
    except Exception as e:
        print(f"OCR failed for {image_path}: {e}")
        return ""

def ingest_and_index(files):
    # Load existing vectorstore if it exists
    embed_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2")
    if os.path.exists(INDEX_PATH):
        vectorstore = Chroma(persist_directory=INDEX_PATH, embedding_function=embed_model)
        with open(PROCESSED_FILES_PATH, 'r') as f:
            processed_files = set(json.load(f))
    else:
        vectorstore = None
        processed_files = set()

    new_files = [f for f in files if f.name not in processed_files]
    
    if not new_files:
        if vectorstore is None:
            vectorstore = Chroma(persist_directory=INDEX_PATH, embedding_function=embed_model)
        return vectorstore

    documents = []

    for f in new_files:
        temp_path = f"/tmp/{f.name}"
        os.makedirs("/tmp", exist_ok=True)

        with open(temp_path, "wb") as out:
            out.write(f.read())

        doc = fitz.open(temp_path)
        for page_no in range(len(doc)):
            page = doc[page_no]
            text = page.get_text() or ""
            text = re.sub(r"\s+", " ", text).strip()

            image_paths = []
            image_texts = []
            for img_index, img in enumerate(page.get_images(full=True)):
                xref = img[0]
                base_image = doc.extract_image(xref)
                image_bytes = base_image["image"]
                image_ext = base_image["ext"]
                image_name = f"{f.name}_page{page_no+1}_img{img_index}.{image_ext}"
                image_path = os.path.join(IMAGES_DIR, image_name)
                os.makedirs(IMAGES_DIR, exist_ok=True)
                with open(image_path, "wb") as img_file:
                    img_file.write(image_bytes)
                image_paths.append(image_path)
                
                # Extract text from image using OCR
                ocr_text = extract_text_from_image(image_path)
                if ocr_text:
                    image_texts.append(ocr_text)

            # Combine page text with image text for better searchability
            combined_text = text
            if image_texts:
                combined_text = text + " [IMAGE TEXT] " + " ".join(image_texts)

            if not combined_text and not image_paths:
                continue

            doc_obj = Document(
                page_content=combined_text,
                metadata={
                    "file_name": f.name,
                    "page_no": page_no + 1,
                    "images": image_paths,
                    "has_images": len(image_paths) > 0,
                    "image_texts": image_texts
                }
            )
            documents.append(doc_obj)

        doc.close()

    # Split documents into chunks for better retrieval
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )
    docs = text_splitter.split_documents(documents)

    if vectorstore is None:
        # Create Chroma vector store
        vectorstore = Chroma.from_documents(docs, embed_model, persist_directory=INDEX_PATH)
    else:
        # Add new documents to existing vectorstore
        vectorstore.add_documents(docs)

    # Persist the vectorstore
    vectorstore.persist()

    # Update processed files
    processed_files.update(f.name for f in new_files)
    with open(PROCESSED_FILES_PATH, 'w') as f:
        json.dump(list(processed_files), f)

    return vectorstore
