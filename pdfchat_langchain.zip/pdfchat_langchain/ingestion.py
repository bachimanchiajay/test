import os
import re
import json
import fitz  # PyMuPDF
from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS

INDEX_PATH = "./faiss_index"
PROCESSED_FILES_PATH = "./processed_files.json"
IMAGES_DIR = "./images"

def ingest_and_index(files):
    # Load existing vectorstore if it exists
    if os.path.exists(INDEX_PATH):
        vectorstore = FAISS.load_local(INDEX_PATH, HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2"), allow_dangerous_deserialization=True)
        with open(PROCESSED_FILES_PATH, 'r') as f:
            processed_files = set(json.load(f))
    else:
        vectorstore = None
        processed_files = set()

    new_files = [f for f in files if f.name not in processed_files]
    
    if not new_files:
        return vectorstore or FAISS(HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2"))

    documents = []

    for f in new_files:
        temp_path = f"/tmp/{f.name}"
        os.makedirs("/tmp", exist_ok=True)

        with open(temp_path, "wb") as out:
            out.write(f.read())

        doc = fitz.open(temp_path)
        for page_no in range(len(doc)):
            page = doc[page_no]
            text = page.get_text() or ""
            text = re.sub(r"\s+", " ", text).strip()

            image_paths = []
            for img_index, img in enumerate(page.get_images(full=True)):
                xref = img[0]
                base_image = doc.extract_image(xref)
                image_bytes = base_image["image"]
                image_ext = base_image["ext"]
                image_name = f"{f.name}_page{page_no+1}_img{img_index}.{image_ext}"
                image_path = os.path.join(IMAGES_DIR, image_name)
                os.makedirs(IMAGES_DIR, exist_ok=True)
                with open(image_path, "wb") as img_file:
                    img_file.write(image_bytes)
                image_paths.append(image_path)

            if not text and not image_paths:
                continue

            doc_obj = Document(
                page_content=text,
                metadata={
                    "file_name": f.name,
                    "page_no": page_no + 1,
                    "images": image_paths
                }
            )
            documents.append(doc_obj)

        doc.close()

    # Split documents into chunks for better retrieval
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )
    docs = text_splitter.split_documents(documents)

    # Use a better embedding model for accuracy
    embed_model = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-mpnet-base-v2"
    )

    if vectorstore is None:
        # Create FAISS vector store for faster retrieval
        vectorstore = FAISS.from_documents(docs, embed_model)
    else:
        # Add new documents to existing vectorstore
        vectorstore.add_documents(docs)

    # Save the updated vectorstore
    vectorstore.save_local(INDEX_PATH)

    # Update processed files
    processed_files.update(f.name for f in new_files)
    with open(PROCESSED_FILES_PATH, 'w') as f:
        json.dump(list(processed_files), f)

    return vectorstore
