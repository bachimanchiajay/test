# Quick Reference Guide

**PDF Chat with LangChain - v1.0**  
**Python 3.11.9**

---

## 📁 File Structure Overview

```
pdfchat_langchain/
├── app.py                          # Main Streamlit UI (156 lines)
├── ingestion.py                    # PDF processing & indexing (123 lines)
├── querying.py                     # Query & retrieval engine (60 lines)
├── config.py                       # Configuration & credentials (6 lines)
├── requirements.txt                # Dependencies (optimized for Python 3.11.9)
│
├── Documentation:
│   ├── CODE_ANALYSIS.md            # Complete code breakdown (this folder)
│   ├── PYTHON_311_COMPATIBILITY.md # Compatibility report
│   ├── SETUP_GUIDE.md              # Setup instructions
│   ├── OCR_SETUP.md                # OCR configuration
│   └── README.md                   # Project overview
│
└── Auto-generated:
    ├── chroma_db/                  # Vector embeddings database
    ├── images/                     # Extracted images
    └── processed_files.json        # Track processed files
```

---

## 🚀 One-Command Setup

```bash
# macOS
python3.11 -m venv venv && source venv/bin/activate && pip install -r requirements.txt && brew install tesseract && streamlit run app.py

# Linux
python3.11 -m venv venv && source venv/bin/activate && pip install -r requirements.txt && sudo apt-get install tesseract-ocr && streamlit run app.py
```

---

## 📊 Code Summary

| File | Purpose | Lines | Key Classes/Functions |
|------|---------|-------|---------------------|
| **app.py** | Streamlit UI | 156 | `get_vectorstore()`, query cache, result display |
| **ingestion.py** | PDF processing | 123 | `extract_text_from_image()`, `ingest_and_index()` |
| **querying.py** | Query engine | 60 | `create_qa_chain()`, `query_and_answer()` |
| **config.py** | Settings | 6 | `API_URL`, `API_KEY` |

---

## 🔄 Data Pipeline

```
User Uploads PDFs
    ↓
[Extract] Text + Images (PyMuPDF)
    ↓
[OCR] Convert images to text (Tesseract)
    ↓
[Combine] Merge text + OCR text
    ↓
[Split] 1000-char chunks with 200 overlap
    ↓
[Embed] Generate vectors (HuggingFace)
    ↓
[Store] Save to ChromaDB
    
---

User Asks Question
    ↓
[Retrieve] Top-50 similar chunks (embedding search)
    ↓
[Rerank] Score with CrossEncoder (top-5)
    ↓
[Format] Separate text from OCR
    ↓
[Display] Show with images & scores
    ↓
[Cache] Save for repeat queries
```

---

## 🎯 Key Functions

### ingestion.py
```python
extract_text_from_image(image_path)
    → Uses Tesseract OCR to extract text from images
    
ingest_and_index(files)
    → Main function: processes PDFs and stores in ChromaDB
```

### querying.py
```python
create_qa_chain(vectorstore)
    → Initializes: LLM, retriever (k=50), reranker
    
query_and_answer(llm, retriever, reranker, question)
    → Retrieves top-5 results with images and scores
```

### app.py
```python
get_vectorstore(files)
    → Cached function to create/load vectorstore
    
Main query loop:
    → Check cache → Execute if miss → Display results → Cache
```

---

## ⚙️ Configuration

**config.py** - Update before running:
```python
API_URL = "https://your-api-endpoint.com/v1"
API_KEY = "your-api-key"
```

**Environment variables** (alternative):
```bash
export LLAMA_API_URL="https://your-api.com/v1"
export LLAMA_API_KEY="your-key"
```

---

## 📦 Dependencies (Python 3.11.9 Optimized)

**Core LangChain:**
- langchain, langchain-community, langchain-huggingface, langchain-core

**Vector DB:**
- chromadb

**UI:**
- streamlit

**Embeddings & Reranking:**
- sentence-transformers (+ huggingface-hub)

**PDF Processing:**
- PyMuPDF, pdfplumber

**Images & OCR:**
- Pillow, pytesseract (requires Tesseract system package)

**Data:**
- pandas, numpy

**ML:**
- torch, torchvision, torchaudio, onnxruntime

**API:**
- openai, requests

**Utils:**
- langsmith, python-dotenv

---

## 💾 Storage Locations

| Data | Location | Notes |
|------|----------|-------|
| Vector embeddings | `./chroma_db/` | ChromaDB format |
| Extracted images | `./images/` | PNG/JPG from PDFs |
| Processed files tracker | `./processed_files.json` | JSON list |
| User queries cache | Session memory | Lost on browser refresh |

---

## ⚡ Performance Tips

| Action | Impact | How |
|--------|--------|-----|
| Reduce k for retrieval | ⬇️ Speed up | Change `k=50` to `k=20` in querying.py |
| Smaller embeddings model | ⬇️ Memory | Change model in ingestion.py |
| Increase chunk size | ⬇️ Storage | Change `chunk_size=1000` to `2000` |
| Use GPU for embeddings | ⬇️ Time | Install CUDA support for torch |
| Cache queries | ✅ Instant | Already enabled |

---

## 🔍 Troubleshooting Quick Fixes

| Problem | Solution |
|---------|----------|
| OCR not working | `brew install tesseract` (macOS) |
| Out of memory | Reduce chunk size or use smaller model |
| Slow queries | Reduce k (retrieval candidates) |
| API errors | Check config.py credentials |
| PDF not indexing | Verify PDF is valid, has .pdf extension |
| Duplicate results | Clear chroma_db and reindex |

---

## 📊 Understanding Relevance Scores

CrossEncoder scores range from **0 to 1**:

| Score | Meaning | Example |
|-------|---------|---------|
| 0.8-1.0 | Perfect match | Query exactly in document |
| 0.6-0.8 | Very relevant | Strong semantic match |
| 0.4-0.6 | Relevant | Good match but not perfect |
| 0.2-0.4 | Weak match | Tangentially related |
| 0.0-0.2 | Poor match | Rarely returned |

---

## 🎓 Learning Path

1. **Understand the UI** → Open in browser at localhost:8501
2. **Upload a PDF** → See indexing progress
3. **Ask a question** → Get results with scores
4. **View the code** → Read through app.py
5. **Explore ingestion** → See ingestion.py for processing
6. **Study queries** → Understand querying.py ranking logic
7. **Customize** → Modify chunk size, models, etc.

---

## 🔐 Security Checklist

- [ ] API credentials in environment, not hardcoded
- [ ] Use .gitignore to exclude sensitive files
- [ ] Keep Tesseract updated: `brew upgrade tesseract`
- [ ] Regular dependency updates: `pip install --upgrade -r requirements.txt`
- [ ] No sensitive data in PDF filenames
- [ ] Local storage only (no cloud uploads)

---

## 📞 Common Commands

```bash
# Activate environment
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run application
streamlit run app.py

# View in browser
open http://localhost:8501

# Deactivate environment
deactivate

# Clear cache
rm -rf ./chroma_db ./processed_files.json ./images

# Check Python version
python3 --version

# Verify dependencies
pip list

# Update dependencies
pip install --upgrade -r requirements.txt
```

---

## 📈 Scaling Tips

**For larger datasets:**
- Split PDFs into smaller chunks before upload
- Use faster embeddings model: `all-MiniLM-L6-v2`
- Reduce chunk_overlap from 200 to 100
- Batch process PDFs programmatically

**For better accuracy:**
- Use larger embeddings model: `all-mpnet-base-v2` (default)
- Increase retrieval candidates: `k=100`
- Use GPU with torch CUDA

**For production:**
- Use docker for reproducibility
- Add authentication to Streamlit
- Setup monitoring and logging
- Use environment variables for all config

---

## 📚 Key Concepts

**Embeddings**: Convert text to numerical vectors for similarity search
**ChromaDB**: Vector database optimized for embeddings
**CrossEncoder**: Neural network that scores text pairs for relevance
**OCR**: Optical Character Recognition to extract text from images
**RAG**: Retrieval Augmented Generation - find docs then return them
**Chunk**: Small piece of document (1000 chars) for better retrieval
**Overlap**: Keep 200 chars from previous chunk to maintain context

---

## 🎯 Feature Highlights

✅ Multi-document upload  
✅ Exact text extraction (not generation)  
✅ Image extraction with OCR  
✅ Relevance scoring  
✅ Result caching  
✅ CSV export  
✅ Local data storage  
✅ 25-30% faster with Python 3.11  

---

## 📋 Checklist for First Run

- [ ] Python 3.11.9 installed
- [ ] Virtual environment created
- [ ] Dependencies installed: `pip install -r requirements.txt`
- [ ] Tesseract OCR installed: `brew install tesseract`
- [ ] config.py API credentials updated
- [ ] Streamlit running: `streamlit run app.py`
- [ ] Browser opened at localhost:8501
- [ ] PDF uploaded successfully
- [ ] Query executed and results shown

---

**Version**: 1.0  
**Updated**: 4 February 2026  
**Status**: ✅ Production Ready  
**Python**: 3.11.9 Optimized
