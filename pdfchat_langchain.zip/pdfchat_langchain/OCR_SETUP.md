# OCR Setup for Image Text Extraction

The system now extracts text from images using **Tesseract OCR**. Follow these steps to set it up:

## macOS Installation

```bash
# Install Tesseract using Homebrew
brew install tesseract

# Verify installation
tesseract --version
```

## Linux (Ubuntu/Debian) Installation

```bash
sudo apt-get install tesseract-ocr
tesseract --version
```

## Windows Installation

1. Download installer from: https://github.com/UB-Mannheim/tesseract/wiki
2. Run the installer (default path: `C:\Program Files\Tesseract-OCR`)
3. Add to Python (update `ingestion.py`):
```python
import pytesseract
pytesseract.pytesseract.pytesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
```

## After Installation

Install Python packages:
```bash
pip install -r requirements.txt
```

## How It Works Now

1. **Image Text Extraction**: When PDFs are uploaded, OCR extracts text from all images
2. **Indexed Search**: Image text is combined with page text and indexed in ChromaDB
3. **Query Matching**: When you search, queries match against both page text AND image text
4. **Image Display**: If the matched content has images, they're displayed below the text
5. **Relevance**: Only images from pages with matched content are shown

## Example Flow

**Your Query**: "Find information about insurance claims"

**System Response**:
```
[policy.pdf | Page 3]
Text about claims processing...
📸 *Image(s) present on this page below*

[policy.pdf | Page 7]
Text about claim forms...
📸 *Image(s) present on this page below*

🖼️ Relevant Images from Retrieved Pages:
[Image 1 - Shows claims form]
[Image 2 - Shows processing flow]
```

## Performance Notes

- First run with images takes longer (OCR processing time)
- Results are cached - repeat queries are instant
- OCR quality depends on image clarity
- Combine page text + image text for comprehensive search
